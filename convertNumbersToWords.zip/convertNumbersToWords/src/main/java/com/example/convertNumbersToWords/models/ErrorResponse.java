package com.example.convertNumbersToWords.models;

import org.springframework.http.HttpStatus;

public class ErrorResponse
{
	public ErrorResponse() {
		
	}
    
    public ErrorResponse(HttpStatus status, int statusCode, String errorMessage, String details) {
		super();
		this.status = status;
		this.statusCode = statusCode;
		this.errorMessage = errorMessage;
		this.details = details;
	}

	private HttpStatus status;
    private int statusCode;
    private String errorMessage;
    private String details;
    
	public HttpStatus getStatus() {
		return status;
	}
	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
}