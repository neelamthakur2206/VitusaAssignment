package com.example.convertNumbersToWords.implementations;

import com.example.convertNumbersToWords.interfaces.NumbersToWordsAbstractClass;
import com.example.convertNumbersToWords.interfaces.NumbersToWordsInterface;

public class NumbersToAmericanEnglishWords extends NumbersToWordsAbstractClass implements NumbersToWordsInterface{

	@Override
	public String convertNumberToWord(Long number) {
		// TODO Auto-generated method stub
		return null;
	}

}
