package com.example.convertNumbersToWords.services;

import org.springframework.stereotype.Service;

import com.example.convertNumbersToWords.factory.NumbersToWordsFactory;

@Service
public class NumbersToWordsServicesImpl {

	public String convertNumberToWord(Long number, String wordType) {
		// TODO Auto-generated method stub
		String numberInWords = NumbersToWordsFactory.getInstance(wordType).convertNumberToWord(number);
		return numberInWords;
	}
	
}
